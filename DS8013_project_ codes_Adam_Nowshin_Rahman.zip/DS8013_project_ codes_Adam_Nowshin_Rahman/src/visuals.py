import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns

def plot_with_history(model_name, X_val_sample, y_val_sample, preds_sample, processor, sample_idx=0):
    """
    Plots historical context (24m) + actual future (6m) + predicted future (6m).
    Scaled down for better notebook visibility.
    """
     
    plt.figure(figsize=(8, 4))

    # 1. Process Past (24 months)
    past_scaled = X_val_sample[:, 0]
    past_inflation = processor.inverse_transform_target(past_scaled).flatten()

    # 2. Process Future (6 months)
    actual_future = processor.inverse_transform_target(y_val_sample).flatten()
    pred_future = processor.inverse_transform_target(preds_sample).flatten()

    # 3. Setup X-axis ranges
    past_range = range(len(past_inflation))
    future_range = range(len(past_inflation), len(past_inflation) + len(actual_future))

    # 4. Plotting
    plt.plot(past_range, past_inflation, label="Past Inflation", color="black", linewidth=1.5)
    plt.plot(future_range, actual_future, label="Actual Future", color="#1f77b4", marker="o", markersize=4)
    plt.plot(future_range, pred_future, label=f"Pred ({model_name})", color="#d62728", linestyle="--", marker="x", markersize=4)

    # Styling
    plt.axvline(x=len(past_inflation)-1, color='gray', linestyle=':', alpha=0.5)
    plt.title(f"{model_name}: Historical Context & Forecast", fontsize=11)
    plt.xlabel("Months", fontsize=9)
    plt.ylabel("Inflation", fontsize=9)
    plt.legend(loc="upper left", fontsize=8)
    plt.grid(True, alpha=0.2)
    plt.tight_layout()
    plt.show()

def plot_metrics_comparison(results_list):
    """
    Comparison bar charts for the final summary.
    Scaled down and optimized for 2-column view.
    """
    df = pd.DataFrame(results_list)
    # Reduced size from (15, 5) to (10, 4)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    
    # RMSE Plot
    sns.barplot(x="Model", y="RMSE", data=df, ax=axes[0], palette="Blues_d")
    axes[0].set_title("RMSE (Lower is Better)", fontsize=10)
    axes[0].tick_params(axis='x', rotation=30, labelsize=8)
    axes[0].set_xlabel("")

    # Directional Accuracy Plot
    sns.barplot(x="Model", y="Direction", data=df, ax=axes[1], palette="Greens_d")
    axes[1].set_title("Directional Accuracy (Higher is Better)", fontsize=10)
    axes[1].tick_params(axis='x', rotation=30, labelsize=8)
    axes[1].set_xlabel("")
    
    plt.tight_layout()
    plt.show()
